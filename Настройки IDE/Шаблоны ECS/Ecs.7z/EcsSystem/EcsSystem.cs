﻿using Leopotam.EcsLite;
using System;

namespace $rootnamespace$
{
    /// <summary>
    ///     .
    /// </summary>
    public sealed class $safeitemname$ : IEcsPreInitSystem, IEcsInitSystem, IEcsRunSystem, IEcsPostRunSystem, IEcsDestroySystem, IEcsPostDestroySystem
    {
        private EcsFilter filter;

        public $safeitemname$()
        {
        }

        /// <inheritdoc/>
        public void PreInit(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public void Init(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public void Run(IEcsSystems systems)
        {
            foreach (var entity in filter)
            {
                throw new NotImplementedException();
            }
        }

        /// <inheritdoc/>
        public void PostRun(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public void Destroy(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public void PostDestroy(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }
    }
}
