﻿using Leopotam.EcsLite;
using System;

namespace $rootnamespace$
{
    /// <summary>
    ///     .
    /// </summary>
    public sealed class $safeitemname$ : IEcsPreInitSystem, IEcsInitSystem, IEcsRunSystem, IEcsPostRunSystem, IEcsDestroySystem, IEcsPostDestroySystem
    {
        private EcsFilter filter;

        public $safeitemname$()
        {
        }

        public void PreInit(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        public void Init(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        public void Run(IEcsSystems systems)
        {
            foreach (var entity in filter)
            {
                throw new NotImplementedException();
            }
        }

        public void PostRun(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        public void Destroy(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }

        public void PostDestroy(IEcsSystems systems)
        {
            throw new NotImplementedException();
        }
    }
}
