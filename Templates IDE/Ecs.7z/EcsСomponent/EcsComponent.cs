﻿using Leopotam.EcsLite;

namespace $rootnamespace$
{
    /// <summary>
    ///     .
    /// </summary>
    public struct $safeitemname$
    {
        public EcsPackedEntityWithWorld Value;

        public override string ToString() => "$safeitemname$";
    }
}
